#ifndef	_ASN1FIX_CSTRING_H_
#define	_ASN1FIX_CSTRING_H_

int asn1f_fix_cstring(arg_t *);

#endif	/* _ASN1FIX_CSTRING_H_ */
