#ifndef	_ASN1C_CONSTRAINT_H_
#define	_ASN1C_CONSTRAINT_H_

int asn1c_emit_constraint_checking_code(arg_t *arg);

#endif	/* _ASN1C_CONSTRAINT_H_ */
